package sec10;

public class Cat extends Animal{

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		
	}

}
