package sec06.exam04;

public class Car {
	//�ʵ�
	public Tire tire;
		
	//�޼ҵ�
	public void run() {
		tire.roll();
	}
		
}
