package sec04;

public class Animal {
	void cry() {
		System.out.println("��ϴ�.");
	}
}
