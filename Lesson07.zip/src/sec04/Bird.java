package sec04;

public class Bird extends Animal{
	@Override
	void cry() {
		System.out.println("±±�ϰ� ��ϴ�.");
	}
}
