package Q.Q2;

public class SnowTire extends Tire{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
	
}
