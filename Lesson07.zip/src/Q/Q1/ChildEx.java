package Q.Q1;

public class ChildEx {

	public static void main(String[] args) {

		Child child = new Child();
	}

}
